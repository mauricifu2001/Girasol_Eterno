/**
 * juego.js — Mundo compartido multijugador
 * Usa Firebase Realtime Database para sincronización en tiempo real.
 *
 * CONFIGURACIÓN:
 *   1. Ve a https://console.firebase.google.com
 *   2. Crea un proyecto (gratis)
 *   3. Ve a Realtime Database → Crear base de datos (modo de prueba)
 *   4. Ve a Configuración del proyecto → Tus apps → Web → Registra app
 *   5. Copia los valores y pégalos en el objeto FIREBASE_CONFIG de abajo
 */

const FIREBASE_CONFIG = {
    apiKey:            "REEMPLAZA_ESTO",
    authDomain:        "REEMPLAZA_ESTO",
    databaseURL:       "REEMPLAZA_ESTO",
    projectId:         "REEMPLAZA_ESTO",
    storageBucket:     "REEMPLAZA_ESTO",
    messagingSenderId: "REEMPLAZA_ESTO",
    appId:             "REEMPLAZA_ESTO"
};

/* ─── Jugadores fijos (igual que config.js) ─── */
const PLAYERS = {
    Mauricio: { slot: "M", orbClass: "who-m" },
    Valentina: { slot: "V", orbClass: "who-v" }
};

/* ─── Mapa ─── */
const MAP_COLS = 20, MAP_ROWS = 7;
const TILE = {
    grass:    { color: "#2a4a1e", freq: 0.38 },
    forest:   { color: "#1a3312", freq: 0.22 },
    mountain: { color: "#3a3228", freq: 0.12 },
    water:    { color: "#1a2a3a", freq: 0.10 },
    sand:     { color: "#4a3c20", freq: 0.10 },
    mine:     { color: "#2c2c2c", freq: 0.08 }
};

/* ─── Eventos aleatorios ─── */
const EVENTOS = [
    {
        title: "Tormenta de estrellas ✨",
        text: "Una lluvia de estrellas ilumina el cielo. El mundo se llena de energía — +3 comida y +2 madera para todos.",
        label: "Contemplar juntos",
        effect: s => { s.food += 3; s.wood += 2; }
    },
    {
        title: "Mercader misterioso 🧙",
        text: "Un viajero aparece en el horizonte. Ofrece 4 gemas a cambio de 6 comida. ¿Aceptan el trato?",
        label: "Aceptar trato",
        effect: s => { if (s.food >= 6) { s.food -= 6; s.gems += 4; } }
    },
    {
        title: "Yacimiento oculto 💎",
        text: "Explorando nuevas tierras, encuentran un yacimiento escondido bajo la roca. +3 gemas.",
        label: "Recoger gemas",
        effect: s => { s.gems += 3; }
    },
    {
        title: "Noche mágica 🌙",
        text: "La luna llena baña el mundo de luz dorada. Todo lo cosechado esta noche vale el doble. +4 comida.",
        label: "Aprovechar la noche",
        effect: s => { s.food += 4; }
    },
    {
        title: "Árbol milenario 🌳",
        text: "Encuentran un árbol ancestral que dejó caer sus ramas más viejas. +5 madera.",
        label: "Recoger madera",
        effect: s => { s.wood += 5; }
    },
    {
        title: "Festival del pueblo 🎉",
        text: "Los habitantes del mundo celebran un festival. Todos comparten recursos — todos los valores se multiplican.",
        label: "Celebrar",
        effect: s => { s.food = Math.round(s.food * 1.5); s.wood = Math.round(s.wood * 1.5); }
    }
];

/* ─── Estado local ─── */
let myName = null;
let db = null;
let worldRef = null;
let currentState = null;
let eventActive = false;
let worldTiles = null;
let canvas = null;
let ctx = null;

/* ─── Detectar jugador según config.js ─── */
function detectPlayer() {
    const config = window.appConfig || {};
    const portal = config.portal || {};
    const profiles = portal.authorizedProfiles || [];

    // Leer sesión guardada por el portal
    const sessionLabel = sessionStorage.getItem("girasolAccessLabel")
        || localStorage.getItem("girasolAccessLabel");

    if (sessionLabel && PLAYERS[sessionLabel]) {
        return sessionLabel;
    }

    // Fallback: si hay un solo authorized profile activo
    if (profiles.length > 0) {
        const first = profiles[0].label;
        if (PLAYERS[first]) return first;
    }

    return null;
}

/* ─── Generador de mapa determinístico ─── */
function generateTiles(seed) {
    let r = seed;
    const rand = () => { r = (r * 1664525 + 1013904223) & 0xffffffff; return (r >>> 0) / 0xffffffff; };
    const types = Object.keys(TILE);
    return Array.from({ length: MAP_ROWS }, (_, row) =>
        Array.from({ length: MAP_COLS }, (_, col) => {
            if (col === 0 || col === MAP_COLS - 1 || row === 0 || row === MAP_ROWS - 1) return "water";
            const n = rand();
            let acc = 0;
            for (const t of types) { acc += TILE[t].freq; if (n < acc) return t; }
            return "grass";
        })
    );
}

/* ─── Dibujar mapa ─── */
function drawWorld(state) {
    if (!canvas || !ctx || !worldTiles) return;
    const W = canvas.width, H = canvas.height;
    const tw = Math.floor(W / MAP_COLS), th = Math.floor(H / MAP_ROWS);
    ctx.clearRect(0, 0, W, H);

    // Tiles
    for (let row = 0; row < MAP_ROWS; row++) {
        for (let col = 0; col < MAP_COLS; col++) {
            const t = worldTiles[row][col];
            ctx.fillStyle = TILE[t]?.color || "#222";
            ctx.fillRect(col * tw, row * th, tw, th);
        }
    }

    // Construcciones
    (state.builds || []).forEach(b => {
        ctx.fillStyle = "rgba(240,194,123,0.25)";
        ctx.fillRect(b.x * tw + 1, b.y * th + 1, tw - 2, th - 2);
        ctx.fillStyle = "#f0c27b";
        ctx.font = `${Math.max(10, th - 4)}px serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("🏠", b.x * tw + tw / 2, b.y * th + th / 2);
    });

    // Jugadores
    const positions = state.positions || { M: { x: 2, y: 3 }, V: { x: 17, y: 3 } };
    const playerColors = { M: "#f0c27b", V: "#f09f9c" };
    const playerNames = { M: "M", V: "V" };

    Object.entries(positions).forEach(([slot, pos]) => {
        const cx = pos.x * tw + tw / 2;
        const cy = pos.y * th + th / 2;
        const r = Math.min(tw, th) * 0.38;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fillStyle = playerColors[slot] || "#fff";
        ctx.fill();
        ctx.fillStyle = "#1c1416";
        ctx.font = `bold ${Math.round(r * 1.1)}px Sora, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(playerNames[slot], cx, cy);
    });

    ctx.textAlign = "start";
    ctx.textBaseline = "alphabetic";
}

/* ─── Mover jugador aleatoriamente ─── */
function movePlayer(state, slot) {
    const pos = { ...(state.positions?.[slot] || { x: slot === "M" ? 2 : 17, y: 3 }) };
    const dirs = [[0, -1], [0, 1], [-1, 0], [1, 0]];
    for (let i = 0; i < 15; i++) {
        const d = dirs[Math.floor(Math.random() * dirs.length)];
        const nx = Math.max(1, Math.min(MAP_COLS - 2, pos.x + d[0]));
        const ny = Math.max(1, Math.min(MAP_ROWS - 2, pos.y + d[1]));
        if (worldTiles?.[ny]?.[nx] !== "water") { pos.x = nx; pos.y = ny; break; }
    }
    if (!state.positions) state.positions = { M: { x: 2, y: 3 }, V: { x: 17, y: 3 } };
    state.positions[slot] = pos;
}

/* ─── Log ─── */
function addLog(state, who, msg) {
    if (!state.log) state.log = [];
    const slot = PLAYERS[who]?.slot || "?";
    state.log.push({ who, slot, msg, t: Date.now() });
    if (state.log.length > 80) state.log = state.log.slice(-80);
}

function renderLog(log) {
    const el = document.getElementById("gameLog");
    if (!el) return;
    const entries = (log || []).slice(-40);
    el.innerHTML = entries.map(e => {
        const cls = e.slot === "M" ? "who-m" : e.slot === "V" ? "who-v" : "";
        return `<div class="juego-log-entry"><span class="juego-log-who ${cls}">${e.who}</span> — ${e.msg}</div>`;
    }).join("");
    el.scrollTop = el.scrollHeight;
}

/* ─── HUD ─── */
function renderHUD(state) {
    document.getElementById("hud-food").textContent = Math.round(state.food || 0);
    document.getElementById("hud-wood").textContent = Math.round(state.wood || 0);
    document.getElementById("hud-gems").textContent = Math.round(state.gems || 0);
    document.getElementById("hud-builds").textContent = (state.builds || []).length;
    document.getElementById("hud-day").textContent = state.day || 1;
}

/* ─── Evento ─── */
function renderEvento(state) {
    const panel = document.getElementById("eventoPanel");
    if (!panel) return;

    if (state.activeEvent) {
        document.getElementById("eventoTitle").textContent = state.activeEvent.title;
        document.getElementById("eventoText").textContent = state.activeEvent.text;
        document.getElementById("eventoAccept").textContent = state.activeEvent.label;
        panel.classList.remove("hidden");
        eventActive = true;
    } else {
        panel.classList.add("hidden");
        eventActive = false;
    }
}

/* ─── Render completo ─── */
function renderAll(state) {
    if (!state) return;
    renderHUD(state);
    renderLog(state.log);
    renderEvento(state);
    drawWorld(state);
}

/* ─── Acciones ─── */
async function doAction(type) {
    if (!worldRef || !myName) return;
    const slot = PLAYERS[myName].slot;

    const snap = await worldRef.once("value");
    const state = snap.val();
    if (!state) return;

    let msg = "";

    switch (type) {
        case "farm":
            state.food = (state.food || 0) + 2;
            msg = "cosechó +2 comida 🌾";
            movePlayer(state, slot);
            break;
        case "chop":
            state.wood = (state.wood || 0) + 2;
            msg = "taló un árbol +2 madera 🪵";
            movePlayer(state, slot);
            break;
        case "mine":
            state.gems = (state.gems || 0) + 1;
            msg = "minó +1 gema 💎";
            movePlayer(state, slot);
            break;
        case "build":
            if ((state.wood || 0) < 3 || (state.food || 0) < 2) {
                addLog(state, myName, "no hay recursos suficientes para construir");
                await worldRef.set(state);
                return;
            }
            state.wood -= 3;
            state.food -= 2;
            if (!state.builds) state.builds = [];
            const bpos = { ...state.positions?.[slot] || { x: 5, y: 3 } };
            state.builds.push(bpos);
            msg = "construyó una nueva estructura 🏠";
            break;
        case "explore":
            movePlayer(state, slot);
            movePlayer(state, slot);
            msg = "exploró nuevas tierras 🗺️";
            if (Math.random() < 0.4 && !state.activeEvent) {
                const idx = Math.floor(Math.random() * EVENTOS.length);
                const ev = EVENTOS[idx];
                state.activeEvent = { title: ev.title, text: ev.text, label: ev.label, idx };
                msg += " — ¡encontró algo!";
            }
            break;
        case "trade":
            if ((state.gems || 0) < 1) {
                addLog(state, myName, "no hay gemas para intercambiar");
                await worldRef.set(state);
                return;
            }
            state.gems -= 1;
            state.food = (state.food || 0) + 3;
            msg = "intercambió 1 💎 por 3 🌾";
            break;
    }

    addLog(state, myName, msg);
    state.actionCount = (state.actionCount || 0) + 1;
    if (state.actionCount % 10 === 0) state.day = (state.day || 1) + 1;

    await worldRef.set(state);
}

/* ─── Chat ─── */
async function sendChat() {
    const input = document.getElementById("chatInput");
    const msg = input.value.trim();
    if (!msg || !worldRef || !myName) return;
    input.value = "";

    const snap = await worldRef.once("value");
    const state = snap.val();
    if (!state) return;

    addLog(state, myName + " 💬", msg);
    await worldRef.set(state);
}

/* ─── Evento: aceptar / ignorar ─── */
async function handleEventoAccept() {
    if (!worldRef) return;
    const snap = await worldRef.once("value");
    const state = snap.val();
    if (!state || !state.activeEvent) return;

    const idx = state.activeEvent.idx;
    if (idx !== undefined && EVENTOS[idx]) {
        EVENTOS[idx].effect(state);
        addLog(state, myName, `resolvió el evento: ${state.activeEvent.title}`);
    }
    state.activeEvent = null;
    await worldRef.set(state);
}

async function handleEventoIgnore() {
    if (!worldRef) return;
    const snap = await worldRef.once("value");
    const state = snap.val();
    if (!state) return;
    addLog(state, myName, "ignoró el evento");
    state.activeEvent = null;
    await worldRef.set(state);
}

/* ─── Lobby ─── */
function updateLobbyUI(state) {
    const mOnline = state.online?.M === true;
    const vOnline = state.online?.V === true;

    const orbM = document.getElementById("slotMauricio")?.querySelector(".juego-player-orb");
    const orbV = document.getElementById("slotValentina")?.querySelector(".juego-player-orb");
    const statusM = document.getElementById("statusMauricio");
    const statusV = document.getElementById("statusValentina");

    if (orbM) orbM.classList.toggle("connected", mOnline);
    if (orbV) orbV.classList.toggle("connected", vOnline);
    if (statusM) { statusM.textContent = mOnline ? "Conectado/a ✓" : "Esperando..."; statusM.className = "juego-player-status" + (mOnline ? " online" : ""); }
    if (statusV) { statusV.textContent = vOnline ? "Conectado/a ✓" : "Esperando..."; statusV.className = "juego-player-status" + (vOnline ? " online" : ""); }
}

/* ─── Inicializar Firebase y juego ─── */
function init() {
    // Detectar jugador
    myName = detectPlayer();
    if (!myName) {
        // Si no hay sesión del portal, intentar detectar por URL param (para pruebas)
        const params = new URLSearchParams(location.search);
        const p = params.get("player");
        if (p && PLAYERS[p]) myName = p;
    }

    if (!myName) {
        document.getElementById("lobbyMessage").textContent =
            "Entra primero desde la página principal para que el juego sepa quién eres.";
        document.getElementById("waitingSection").style.display = "none";
        return;
    }

    const slot = PLAYERS[myName].slot;

    // Firebase
    if (FIREBASE_CONFIG.apiKey === "REEMPLAZA_ESTO") {
        document.getElementById("lobbyMessage").textContent =
            "Falta configurar Firebase. Sigue las instrucciones en juego.js.";
        return;
    }

    if (!firebase.apps.length) {
        firebase.initializeApp(FIREBASE_CONFIG);
    }
    db = firebase.database();
    worldRef = db.ref("mundo");

    // Canvas
    canvas = document.getElementById("worldCanvas");
    ctx = canvas?.getContext("2d");

    // Marcar presencia
    worldRef.child(`online/${slot}`).set(true);
    worldRef.child(`online/${slot}`).onDisconnect().set(false);

    // Escuchar cambios en tiempo real
    worldRef.on("value", snap => {
        const state = snap.val();
        if (!state) return;

        currentState = state;
        const bothOnline = state.online?.M === true && state.online?.V === true;

        if (!state.started && bothOnline) {
            // Iniciar mundo si ambos están conectados
            const seed = state.mapSeed || (Math.floor(Math.random() * 99999) + 1000);
            worldTiles = generateTiles(seed);
            const initState = {
                ...state,
                started: true,
                mapSeed: seed,
                food: 6,
                wood: 6,
                gems: 2,
                builds: [],
                day: 1,
                actionCount: 0,
                positions: { M: { x: 2, y: 3 }, V: { x: 17, y: 3 } },
                log: [{ who: "Sistema", slot: "S", msg: "El mundo despertó. ¡Comiencen la aventura juntos!", t: Date.now() }],
                activeEvent: null
            };
            worldRef.set(initState);
            return;
        }

        if (state.started) {
            if (!worldTiles && state.mapSeed) {
                worldTiles = generateTiles(state.mapSeed);
            }
            showScreen("screenGame");
            renderAll(state);
        } else {
            updateLobbyUI(state);
        }
    });

    // Botones de acción
    document.querySelectorAll(".juego-accion").forEach(btn => {
        btn.addEventListener("click", () => doAction(btn.dataset.action));
    });

    // Chat
    document.getElementById("chatSend")?.addEventListener("click", sendChat);
    document.getElementById("chatInput")?.addEventListener("keydown", e => {
        if (e.key === "Enter") sendChat();
    });

    // Evento
    document.getElementById("eventoAccept")?.addEventListener("click", handleEventoAccept);
    document.getElementById("eventoIgnore")?.addEventListener("click", handleEventoIgnore);
}

function showScreen(id) {
    document.querySelectorAll(".juego-screen").forEach(s => {
        s.classList.toggle("hidden", s.id !== id);
    });
}

window.addEventListener("load", init);
